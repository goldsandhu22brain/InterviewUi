


 $(document).ready(function() {
	$('#example').DataTable();
} );



 $(document).ready(function() {
	$('#company-table').DataTable();
} );

//Write a function to Show popup that you are not authorized to download the file